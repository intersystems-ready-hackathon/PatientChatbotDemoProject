import collections
import datetime
import decimal
import enum
import functools
import itertools
import random
import re
import uuid
import warnings

import iris
import iris.dbapi
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore


# Regular expressions for allowed identifiers in SQL statements, for preventing
# SQL injection.
_TABLE_NAME_RE = r'[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?'
_COLUMN_NAME_RE = r'[A-Za-z0-9_]+'  # can start with number because metadata prefix is prepended

# Prefix for metadata column names to prevent clashing with non-metadata column
# names.
_METADATA_PREFIX = 'm_'
_METADATA_PREFIX_LEN = len(_METADATA_PREFIX)

_SUPPORTED_METADATA_TYPES = {
    str,
    bytes,
    int,
    float,
    bool,
    decimal.Decimal,
    datetime.date,
    datetime.time,
    datetime.datetime,
    uuid.UUID,
}


# compatibility shims for earlier Python versions
if hasattr(itertools, 'batched'):
    batched = itertools.batched
else:
    def batched(iterable, n, *, strict=False):
        # batched('ABCDEFG', 3) -> ABC DEF G
        if n < 1:
            raise ValueError('n must be at least one')
        iterator = iter(iterable)
        while batch := tuple(itertools.islice(iterator, n)):
            if strict and len(batch) != n:
                raise ValueError('batched(): incomplete batch')
            yield batch
if hasattr(enum, 'StrEnum'):
    _StrEnum = enum.StrEnum
else:
    class _StrEnum(str, enum.Enum):
        def __format__(self, format_spec):
            return self.value.format(format_spec)

        def __str__(self):
            return self.value


class SimilarityMetric(_StrEnum):
    """Metrics that can be used to find similar documents"""
    COSINE = 'VECTOR_COSINE'
    DOT_PRODUCT = 'VECTOR_DOT_PRODUCT'


class Predicate(_StrEnum):
    """SQL predicates that can be used in metadata filters"""
    AND = '$and'
    OR = '$or'
    NOT = '$not'

    EQUAL = '$eq'
    NOT_EQUAL = '$ne'
    GREATER_THAN = '$gt'
    GREATER_THAN_OR_EQUAL = '$gte'
    LESS_THAN = '$lt'
    LESS_THAN_OR_EQUAL = '$lte'
    IS_NULL = '$isnull'
    IS_NOT_NULL = '$notnull'
    BETWEEN = '$between'
    IN = '$in'
    CONTAINS = '$contains'
    NOT_CONTAINS = '$ncontains'
    FOLLOWS = '$follows'
    NOT_FOLLOWS = '$nfollows'
    STARTS_WITH = '$startswith'
    LIKE = '$like'
    MATCHES = '$matches'
    PATTERN = '$pattern'


def _convert_type(arg):
    """Convert arg to a type that is acceptable to a parametrized SQL query
    that uses DB-API."""
    return str(arg) if isinstance(arg, uuid.UUID) else arg


def _filter_to_condition(filter: dict) -> tuple[str, list]:
    """Given a filter expression, return a tuple where the first element is a
    parameterized condition expression for an IRIS SQL WHERE clause and the
    second element is a list of arguments."""
    if not isinstance(filter, dict):
        raise TypeError('filter must be a dict')
    if not filter:
        raise ValueError('filter must have at least 1 item')
    conditions = []
    args = []
    metadata_keys_lower = set()
    for k, v in filter.items():
        if not isinstance(k, str):
            raise TypeError('filter key must have type str or Predicate')
        if not k:
            raise ValueError('filter key cannot be empty')
        if k == Predicate.AND:
            if not isinstance(v, list):
                raise TypeError(f'filter value for {k} predicate must have type list')
            if not v:
                warnings.warn(f'{k} of no predicates is always true')
                conditions.append('1=1')
            elif len(v) == 1:
                inner_condition, args[len(args):] = _filter_to_condition(v[0])
                conditions.append(inner_condition)
            else:
                inner_conditions = []
                for inner_filter in v:
                    inner_condition, args[len(args):] = _filter_to_condition(inner_filter)
                    inner_conditions.append(f'({inner_condition})')
                conditions.append(' AND '.join(inner_conditions))
        elif k == Predicate.OR:
            if not isinstance(v, list):
                raise TypeError(f'filter value for {k} predicate must have type list')
            if not v:
                warnings.warn(f'{k} of no predicates is always false')
                conditions.append('0=1')
            elif len(v) == 1:
                inner_condition, args[len(args):] = _filter_to_condition(v[0])
                conditions.append(inner_condition)
            else:
                inner_conditions = []
                for inner_filter in v:
                    inner_condition, args[len(args):] = _filter_to_condition(inner_filter)
                    inner_conditions.append(f'({inner_condition})')
                conditions.append(' OR '.join(inner_conditions))
        elif k == Predicate.NOT:
            inner_condition, args[len(args):] = _filter_to_condition(v)
            conditions.append(f'NOT ({inner_condition})')
        elif k[0] == '$':
            raise ValueError(f'unsupported predicate {k}')
        elif not re.fullmatch(_COLUMN_NAME_RE, k):
            raise ValueError(f'invalid metadata field name {k}')
        else:
            # key is a metadata field name
            if (k := k.lower()) in metadata_keys_lower:
                raise ValueError(f'filter key {k!r} has more than 1 case variation, which is not allowed')
            metadata_keys_lower.add(k)
            if isinstance(v, tuple):
                if not v:
                    raise ValueError(f'invalid filter value {v!r} for metadata key {k!r}')
                if v[0] == Predicate.EQUAL:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} = ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.NOT_EQUAL:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} != ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.GREATER_THAN:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} > ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.GREATER_THAN_OR_EQUAL:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} >= ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.LESS_THAN:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} < ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.LESS_THAN_OR_EQUAL:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} <= ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.IS_NULL:
                    if len(v) != 1:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 1')
                    conditions.append(f'{_METADATA_PREFIX}{k} IS NULL')
                elif v[0] == Predicate.IS_NOT_NULL:
                    if len(v) != 1:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 1')
                    conditions.append(f'{_METADATA_PREFIX}{k} IS NOT NULL')
                elif v[0] == Predicate.BETWEEN:
                    if len(v) != 3:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 3')
                    conditions.append(f'{_METADATA_PREFIX}{k} BETWEEN ? AND ?')
                    args.append(_convert_type(v[1]))
                    args.append(_convert_type(v[2]))
                elif v[0] == Predicate.IN:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    if not isinstance(v[1], list):
                        raise TypeError(f'predicate {v[0]} for metadata key {k!r} must be followed by a list')
                    if v[1]:
                        conditions.append(f'{_METADATA_PREFIX}{k} IN ({",".join("?"*len(v[1]))})')
                        args.extend(_convert_type(elt) for elt in v[1])
                    else:
                        warnings.warn(f'predicate {v[0]} for metadata key {k!r} is followed by an empty list, which is always false')
                        conditions.append('0=1')
                elif v[0] == Predicate.CONTAINS:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} [ ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.NOT_CONTAINS:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} NOT[ ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.FOLLOWS:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} ] ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.NOT_FOLLOWS:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} NOT] ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.STARTS_WITH:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} %STARTSWITH ?')
                    args.append(_convert_type(v[1]))
                elif v[0] == Predicate.LIKE:
                    if len(v) == 2:
                        conditions.append(f'{_METADATA_PREFIX}{k} LIKE ?')
                        args.append(_convert_type(v[1]))
                    elif len(v) == 3:
                        conditions.append(f'{_METADATA_PREFIX}{k} LIKE ? ESCAPE ?')
                        args.append(_convert_type(v[1]))
                        args.append(_convert_type(v[2]))
                    else:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2 or 3')
                elif v[0] == Predicate.MATCHES:
                    if len(v) == 2:
                        conditions.append(f'{_METADATA_PREFIX}{k} %MATCHES ?')
                        args.append(_convert_type(v[1]))
                    elif len(v) == 3:
                        conditions.append(f'{_METADATA_PREFIX}{k} %MATCHES ? ESCAPE ?')
                        args.append(_convert_type(v[1]))
                        args.append(_convert_type(v[2]))
                    else:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2 or 3')
                elif v[0] == Predicate.PATTERN:
                    if len(v) != 2:
                        raise ValueError(f'filter value for metadata key {k!r} must have length 2')
                    conditions.append(f'{_METADATA_PREFIX}{k} %PATTERN ?')
                    args.append(_convert_type(v[1]))
                else:
                    raise ValueError(f'invalid filter value {v!r} for metadata key {k!r}')
            elif type(v) in _SUPPORTED_METADATA_TYPES:
                conditions.append(f'{_METADATA_PREFIX}{k} = ?')
                args.append(_convert_type(v))
            else:
                supported_types = {tuple} | _SUPPORTED_METADATA_TYPES
                raise TypeError(f'filter value {v!r} for metadata key {k!r} has an invalid type; supported types are {supported_types!r}')
    return (conditions[0] if len(conditions) == 1 else ' AND '.join(f'({condition})' for condition in conditions)), args


class IRISVectorStore(VectorStore):
    """LangChain vector store that stores documents in InterSystems IRIS"""
    _ID_MAXLEN = 36
    _BATCH_SIZE = 1000
    _COLLECTION_NAME_MAXLEN = 128

    _METADATA_KEY_MAXLEN = 128 - _METADATA_PREFIX_LEN
    _METADATA_STR_MAXLEN = 1024
    _METADATA_STR_COLLATE_MAXLEN = 400  # avoid global subscript length limitation in index
    _METADATA_BYTES_MAXLEN = 1024
    _METADATA_INT_MINVAL = -9223372036854775808
    _METADATA_INT_MAXVAL = 9223372036854775807
    _METADATA_DECIMAL_PRECISION = 27
    _METADATA_DECIMAL_SCALE = 9
    _METADATA_TYPEMAP_PY_TO_SQL = {
        str: f'VARCHAR({_METADATA_STR_MAXLEN}) SQLUPPER({_METADATA_STR_COLLATE_MAXLEN})',
        bytes: f'VARBINARY({_METADATA_BYTES_MAXLEN})',
        int: 'BIGINT',
        float: 'DOUBLE',
        bool: 'BIT',
        decimal.Decimal: f'DECIMAL({_METADATA_DECIMAL_PRECISION},{_METADATA_DECIMAL_SCALE})',
        datetime.date: 'DATE',
        datetime.time: 'TIME',
        datetime.datetime: 'DATETIME',
        uuid.UUID: 'UNIQUEIDENTIFIER',
    }
    _METADATA_TYPEMAP_DBAPI_TO_PY = {
        iris.dbapi.SQLType.VARCHAR: str,
        iris.dbapi.SQLType.VARBINARY: bytes,
        iris.dbapi.SQLType.BIGINT: int,
        iris.dbapi.SQLType.DOUBLE: float,
        iris.dbapi.SQLType.BIT: bool,
        iris.dbapi.SQLType.NUMERIC: decimal.Decimal,
        iris.dbapi.SQLType.DATE: datetime.date,
        iris.dbapi.SQLType.TIME: datetime.time,
        iris.dbapi.SQLType.TIMESTAMP: datetime.datetime,
        iris.dbapi.SQLType.GUID: uuid.UUID,
    }
    _METADATA_INDEX_TYPE = {  # type of index to create for each key type
        str: 'BITMAP INDEX',
        bytes: None,  # no index
        int: 'BITMAP INDEX',
        float: 'INDEX',
        bool: 'BITMAP INDEX',
        decimal.Decimal: 'INDEX',
        datetime.date: 'BITMAP INDEX',
        datetime.time: 'INDEX',
        datetime.datetime: 'INDEX',
        uuid.UUID: None,
    }
    assert _METADATA_TYPEMAP_PY_TO_SQL.keys() == _METADATA_INDEX_TYPE.keys() == _SUPPORTED_METADATA_TYPES

    _embedding_function: Embeddings  # query embedding object
    _connection: iris.IRISConnection  # connection to IRIS
    _collection_name: str  # name of this collection

    # mapping from lowercase metadata column name without prefix to Python type
    # of metadata values
    _metadata_columns: dict[str, type]

    @staticmethod
    def _transaction(*, commit: bool) -> collections.abc.Callable[[collections.abc.Callable], collections.abc.Callable]:
        """Decorator factory for instance method that rolls back any pending
        transaction and restores the _metadata_columns field if an exception
        occurs. If commit is True, then the transaction is committed if the
        method runs successfully."""
        def decorator(func: collections.abc.Callable) -> collections.abc.Callable:
            @functools.wraps(func)
            def wrapper(self: 'IRISVectorStore', *args, **kwargs):
                metadata_columns_backup = self._metadata_columns.copy()
                try:
                    ret = func(self, *args, **kwargs)
                    if commit:
                        self._connection.commit()
                    return ret
                except:
                    self._connection.rollback()
                    self._metadata_columns = metadata_columns_backup
                    raise
            return wrapper
        return decorator

    @staticmethod
    def _check_server_version(conn: iris.IRISConnection):
        """Check whether the connected server version is at least 2025.1, the
        version where Approximate Nearest Neighbor indexing was introduced. If
        not, raise an exception."""
        version_str = iris.createIRIS(conn).classMethodString('%SYSTEM.Version', 'GetNumber')
        if match := re.match(r'(\d+)\.(\d+)(\.(\d+))?', version_str):
            version = int(match[1]), int(match[2]), 0 if match[4] is None else int(match[4])
            if version < (2025, 1, 0):
                raise RuntimeError('Server version must be 2025.1.0 or higher')
        else:
            raise RuntimeError(f'Unrecognized version string {version_str!r}')

    @_transaction(commit=True)
    def _init_table(self, replace_collection: bool, embedding_model: str, dimension: int):
        """Initialize the backend IRIS table.

        Args:
            replace_collection: Whether to replace the table if it already
                exists.
            embedding_model: Name of embedding model or 'unknown' if unknown
            dimension: Dimensionality of embeddings.
        """
        with self._connection.cursor() as cursor:
            if replace_collection:
                cursor.execute(f'DROP TABLE IF EXISTS {self._collection_name}')
            elif cursor.callproc('? = %SYSTEM_SQL.Schema_TableExists(?)', (self._collection_name,))[0]:
                cursor.execute(
                    'SELECT DESCRIPTION FROM INFORMATION_SCHEMA.COLUMNS '
                    "WHERE TABLE_NAME=? AND COLUMN_NAME='embedding'",
                    (self._collection_name,)
                )
                if row := cursor.fetchone():
                    if (match := re.fullmatch(r'(\d+);(.+)', row[0])) is None:
                        raise RuntimeError(f'Existing collection has invalid description {row[0]}')
                    elif (existing_dimension := int(match[1])) != dimension:
                        raise RuntimeError(f'Existing collection contains embeddings with {existing_dimension} dimensions, which differs from the requested {dimension}')
                    elif match[2] != embedding_model:
                        raise RuntimeError(f'Existing collection uses model {match[2]!r}, which differs from the requested {embedding_model!r}')
                else:
                    raise RuntimeError(f'Existing collection has no description')
                cursor.execute(
                    'SELECT COLUMN_NAME,odbctype '
                    'FROM INFORMATION_SCHEMA.COLUMNS '
                    'WHERE TABLE_NAME=? AND COLUMN_NAME %STARTSWITH ? '
                    'ORDER BY ORDINAL_POSITION',
                    (self._collection_name, _METADATA_PREFIX)
                )
                for column_name, odbctype in cursor:
                    self._metadata_columns[column_name[_METADATA_PREFIX_LEN:]] = self._METADATA_TYPEMAP_DBAPI_TO_PY[odbctype]
            embedding_model_escaped = embedding_model.replace("'", "''")
            cursor.execute(
                f'CREATE TABLE IF NOT EXISTS {self._collection_name} ('
                f'id VARCHAR({self._ID_MAXLEN}) PRIMARY KEY, '
                f"embedding VECTOR(float,{dimension}) NOT NULL %DESCRIPTION '{dimension};{embedding_model_escaped}', "
                f'document TEXT NOT NULL)'
            )
            cursor.execute(
                "SELECT INDEX_NAME FROM INFORMATION_SCHEMA.INDEXES WHERE TABLE_NAME=? AND COLUMN_NAME='embedding'",
                (self._collection_name,)
            )
            target_index_found = False
            for ann_index, *_ in cursor:
                if ann_index == self._similarity_metric:
                    target_index_found = True
                else:
                    warnings.warn(f'Existing collection already has a {ann_index} index, which differs from the requested similarity metric of {self._similarity_metric}. This will result in multiple indices, which may hurt performance.')
            if not target_index_found:
                distance = 'Cosine' if self._similarity_metric is SimilarityMetric.COSINE else 'DotProduct'
                self._connection.commit()
                self._connection.autocommit = True  # remove once DP-445908 is fixed
                try:
                    cursor.execute(
                        f'CREATE INDEX {self._similarity_metric} '
                        f'ON TABLE {self._collection_name} (embedding) '
                        f"AS HNSW(Distance='{distance}')"
                    )
                finally:
                    self._connection.autocommit = False  # remove once DP-445908 is fixed

    def __init__(
            self,
            embedding_function: Embeddings,
            connect_args: tuple = (),
            connect_kwargs: dict | None = None,
            collection_name: str = None,
            replace_collection: bool = False,
            similarity_metric: SimilarityMetric = SimilarityMetric.COSINE,
    ):
        """Initialize the vector store.

        Args:
            embedding_function: Embedding function to use.
            connect_args: Positional arguments to pass to iris.dbapi.connect().
            connect_kwargs: Keyword arguments to pass to iris.dbapi.connect().
            collection_name: Name of the backend InterSystems IRIS table that
                holds this collection. If unspecified, a name is generated
                consisting of 'IRISVectorStore' followed by a random number.
            replace_collection: Whether to replace an existing table if
                collection_name already exists in the database.
            similarity_metric: Metric used to compute similarity scores between
                embeddings.
        """
        if not isinstance(embedding_function, Embeddings):
            raise TypeError(f'embedding_function must be an Embeddings')
        self._embedding_function = embedding_function
        for attr in ('model', 'model_name', 'model_id'):
            if hasattr(self._embedding_function, attr) and isinstance(embedding_model := getattr(self._embedding_function, attr), str):
                break
        else:
            embedding_model = 'unknown'
        if not hasattr(self._embedding_function, 'dimensions') or not isinstance(dimension := self._embedding_function.dimensions, int):
            dimension = len(self._embedding_function.embed_query('a'))
        if connect_kwargs is None:
            connect_kwargs = {}
        if (len(connect_args) >= 8 and isinstance(connect_args[7], bool) and connect_args[7] or
                len(connect_args) >= 10 and isinstance(connect_args[9], bool) and connect_args[9] or
                connect_kwargs.get('autoCommit')):
            # warn if user explicitly set autoCommit to True
            warnings.warn('IRISVectorStore requires autoCommit to be False; changing to False')
        self._connection = iris.dbapi.connect(*connect_args, **connect_kwargs)
        self._check_server_version(self._connection)
        self._connection.autocommit = False

        self._collection_name = collection_name or self.__class__.__name__ + str(int.from_bytes(random.randbytes(4), byteorder='big'))
        if not re.fullmatch(_TABLE_NAME_RE, self._collection_name):
            raise ValueError(f'collection_name {self._collection_name!r} must match the regular expression {_TABLE_NAME_RE}')
        elif len(self._collection_name) > self._COLLECTION_NAME_MAXLEN:
            raise ValueError(f'collection_name {self._collection_name!r} exceeds maximum length of {self._COLLECTION_NAME_MAXLEN}')
        if not isinstance(similarity_metric, SimilarityMetric):
            raise TypeError(f'Invalid similarity_metric {similarity_metric}')
        self._similarity_metric = similarity_metric
        self._metadata_columns = {}
        self._init_table(replace_collection, embedding_model, dimension)

    def __del__(self):
        try:
            self._connection.close()
        except AttributeError:
            # self._connection has not been set yet
            pass

    @property
    def embeddings(self) -> Embeddings:
        """Access the query embedding object"""
        return self._embedding_function

    @classmethod
    def from_texts(
            cls,
            texts: list[str],
            embedding: Embeddings,
            metadatas: list[dict] | None = None,
            connect_args: tuple = (),
            connect_kwargs: dict | None = None,
            collection_name: str = None,
            replace_collection: bool = False,
            similarity_metric: SimilarityMetric = SimilarityMetric.COSINE,
            *,
            ids: list[str] | None = None,
    ) -> 'IRISVectorStore':
        """Return VectorStore initialized from texts and embeddings.

        Args:
            texts: Texts to add to the vector store.
            embedding: Embedding function to use.
            metadatas: Optional list of metadatas associated with the texts.
                Default is None.
            connect_args: Positional arguments to pass to iris.dbapi.connect().
            connect_kwargs: Keyword arguments to pass to iris.dbapi.connect().
            collection_name: Name of the backend InterSystems IRIS table that
                holds this collection. If unspecified, a name is generated
                consisting of 'IRISVectorStore' followed by a random number.
            replace_collection: Whether to replace an existing table if
                collection_name already exists in the database.
            similarity_metric: Metric used to compute similarity scores between
                embeddings.
            ids: Optional list of IDs associated with the texts.

        Returns:
            VectorStore: VectorStore initialized from texts and embeddings.
        """
        store = cls(embedding, connect_args, connect_kwargs, collection_name, replace_collection, similarity_metric)
        store.add_texts(texts, metadatas, ids=ids)
        return store

    @classmethod
    def _validate_metadata_value(cls, value):
        """Validate a metadata value. Raise an exception if validation
        fails. Warn if the value may be rounded due to IRIS precision
        limitations."""
        t = type(value)
        if t is str and len(value) > cls._METADATA_STR_MAXLEN:
            raise ValueError(f'metadata value {value!r} exceeds maximum supported length of {cls._METADATA_STR_MAXLEN}')
        elif t is bytes and len(value) > cls._METADATA_BYTES_MAXLEN:
            raise ValueError(f'metadata value {value!r} exceeds maximum supported length of {cls._METADATA_BYTES_MAXLEN}')
        elif t is int and (value < cls._METADATA_INT_MINVAL or value > cls._METADATA_INT_MAXVAL):
            raise ValueError(f'metadata value {value!r} is outside the supported range [{cls._METADATA_INT_MINVAL}, {cls._METADATA_INT_MAXVAL}]')
        elif t is decimal.Decimal:
            if not value.is_finite():
                raise ValueError(f'invalid metadata value {value!r}')
            sign, digits, exp = value.normalize().as_tuple()
            total_digits = len(digits)
            if exp >= 0:
                int_digits = total_digits + exp
                frac_digits = 0
            else:
                frac_digits = -exp
                int_digits = max(0, total_digits - frac_digits)
            if int_digits + cls._METADATA_DECIMAL_SCALE > cls._METADATA_DECIMAL_PRECISION:
                raise ValueError(f'metadata value {value!r} is outside the supported range for SQL type {cls._METADATA_TYPEMAP_PY_TO_SQL[decimal.Decimal]}')
            if frac_digits > cls._METADATA_DECIMAL_SCALE:
                warnings.warn(f'metadata value {value!r} has more than {cls._METADATA_DECIMAL_SCALE} fractional digits and will be rounded')
            # IRIS stores significand as signed 64-bit integer, which
            # guarantees 18 digits of precision. Some numbers with a 19-digit
            # significand are rounded, while all numbers with a 20-digit or
            # longer significand are rounded.
            elif total_digits == 19:
                warnings.warn(f'metadata value {value!r} has more than 18 digits and may be rounded')
            elif total_digits > 19:
                warnings.warn(f'metadata value {value!r} has more than 19 digits and will be rounded')

    @_transaction(commit=True)
    def add_texts(
            self,
            texts: collections.abc.Iterable[str],
            metadatas: list[dict] | None = None,
            *,
            ids: list[str] | None = None,
    ) -> list[str]:
        """Run more texts through the embeddings and add to the `VectorStore`.

        Args:
            texts: Iterable of strings to add to the `VectorStore`.
            metadatas: Optional list of metadatas associated with the texts.
            ids: Optional list of IDs associated with the texts.

        Returns:
            List of IDs from adding the texts into the `VectorStore`.

        Raises:
            ValueError: If the number of metadatas does not match the number of
                texts.
            ValueError: If the number of IDs does not match the number of
                texts.
        """
        if not isinstance(texts, collections.abc.Sequence):
            texts = list(texts)
        if not texts:
            return []
        if metadatas is None:
            metadatas = {}
        elif (metadatas_len := len(metadatas)) != (text_len := len(texts)):
            raise ValueError(f'metadatas ({metadatas_len}) and texts ({text_len}) have different lengths')
        if ids is None:
            ids = []
        elif (ids_len := len(ids)) != (text_len := len(texts)):
            raise ValueError(f'ids ({ids_len}) and texts ({text_len}) have different lengths')
        embedding = self._embedding_function.embed_documents(texts)

        data = []
        return_ids = []
        with self._connection.cursor() as cursor:
            for id, embedding, text, metadata in itertools.zip_longest(ids, embedding, texts, metadatas):
                if id is None:
                    id = str(uuid.uuid4())
                elif len(id) > self._ID_MAXLEN:
                    raise ValueError(f'id {id!r} exceeds maximum supported length of {self._ID_MAXLEN}')
                row = [id, ','.join(map(str, embedding)), text]
                if metadata is None:
                    row.extend([None] * len(self._metadata_columns))
                else:
                    # normalize metadata keys to lowercase
                    metadata_lower = {}
                    for key, value in metadata.items():
                        if not isinstance(key, str):
                            raise TypeError('metadata key must be a str')
                        if (key_lower := key.lower()) in metadata_lower:
                            raise ValueError(f'metadata key {key!r} has more than 1 case variation, which is not allowed')
                        elif value is not None:
                            metadata_lower[key_lower] = value
                        # value None is ignored and treated as if the key-value
                        # pair doesn't exist
                    # validate metadata items and create new columns if needed
                    for key, value in metadata_lower.items():
                        is_new_key = False
                        if not re.fullmatch(_COLUMN_NAME_RE, key):
                            raise ValueError(f'metadata key name {key!r} must match the regular expression {_COLUMN_NAME_RE}')
                        elif len(key) > self._METADATA_KEY_MAXLEN:
                            raise ValueError(f'metadata key name {key!r} exceeds maximum length of {self._METADATA_KEY_MAXLEN}')
                        elif key in self._metadata_columns:
                            if not isinstance(value, self._metadata_columns[key]):
                                raise TypeError(f'metadata value {value!r} does not match column type {self._metadata_columns[key]}')
                        elif (t := type(value)) not in self._METADATA_TYPEMAP_PY_TO_SQL:
                            raise TypeError(f'metadata value of type {t} is not supported; supported types are {list(self._METADATA_TYPEMAP_PY_TO_SQL)}')
                        else:
                            # first time seeing this metadata key
                            is_new_key = True
                        self._validate_metadata_value(value)
                        if is_new_key:
                            # This block is placed after self._validate_metadata_value(value)
                            # because bug DP-445696 prevents ADD COLUMN
                            # commands from rolling back properly in the event
                            # of an exception. Work around this by performing
                            # the validation before adding a column.
                            if data:
                                result = cursor.executemany(
                                    f'INSERT OR UPDATE {self._collection_name} '
                                    f'VALUES ({",".join("?"*len(data[0]))})',
                                    data
                                )
                                if cursor.rowcount != len(data):
                                    raise RuntimeError('\n'.join(filter(lambda item: isinstance(item, str), result)))
                                data.clear()
                            cursor.execute(
                                f'ALTER TABLE {self._collection_name} '
                                f'ADD COLUMN ({_METADATA_PREFIX}{key} {self._METADATA_TYPEMAP_PY_TO_SQL[t]})'
                            )
                            if (index_type := self._METADATA_INDEX_TYPE[t]) is not None:
                                cursor.execute(
                                    f'CREATE {index_type} {_METADATA_PREFIX}index_{key} '
                                    f'ON TABLE {self._collection_name} ({_METADATA_PREFIX}{key})'
                                )
                            self._metadata_columns[key] = t
                    row.extend(_convert_type(metadata_lower.get(key, None)) for key in self._metadata_columns)
                data.append(row)
                return_ids.append(id)
                if len(data) == self._BATCH_SIZE:
                    result = cursor.executemany(
                        f'INSERT OR UPDATE {self._collection_name} '
                        f'VALUES ({",".join("?"*len(data[0]))})',
                        data
                    )
                    if cursor.rowcount != len(data):
                        raise RuntimeError('\n'.join(filter(lambda item: isinstance(item, str), result)))
                    data.clear()
            if data:
                result = cursor.executemany(
                    f'INSERT OR UPDATE {self._collection_name} '
                    f'VALUES ({",".join("?"*len(data[0]))})',
                    data
                )
                if cursor.rowcount != len(data):
                    raise RuntimeError('\n'.join(filter(lambda item: isinstance(item, str), result)))
        return return_ids

    def _select_relevance_score_fn(self) -> collections.abc.Callable[[float], float]:
        """Return the correct relevance score function that normalizes the
        distance returned by similarity_search_with_score() to a value between
        0.0 and 1.0, where 0.0 is least relevant and 1.0 is most relevant.
        """
        return self._cosine_relevance_score_fn if self._similarity_metric is SimilarityMetric.COSINE else self._max_inner_product_relevance_score_fn

    def similarity_search(
            self,
            query: str,
            k: int = 4,
            filter: dict | None = None
    ) -> list[Document]:
        """Return docs most similar to query.

        Args:
            query: Input text.
            k: Number of Documents to return. Defaults to 4.
            filter: Optional metadata filter.

        Returns:
            List of Documents most similar to the query.
        """
        embedding = self._embedding_function.embed_query(query)
        return self.similarity_search_by_vector(embedding, k, filter)

    def _get_metadata(self, values: collections.abc.Sequence) -> dict:
        """Given a sequence of metadata values corresponding to
        self._metadata_columns and in the same order, return the metadata in
        dict form where each metadatum is represented as a key-value pair. None
        values are excluded."""
        metadata = {}
        for (key, t), value in zip(self._metadata_columns.items(), values, strict=True):
            if value is not None:
                if t is uuid.UUID:
                    # DB-API returns UNIQUEIDENTIFIER values as str
                    metadata[key] = uuid.UUID(value)
                elif t is decimal.Decimal:
                    # DB-API can return NUMERIC values as int
                    metadata[key] = decimal.Decimal(value)
                else:
                    metadata[key] = value
        return metadata

    def similarity_search_by_vector(
            self,
            embedding: list[float],
            k: int = 4,
            filter: dict | None = None,
    ) -> list[Document]:
        """Return docs most similar to embedding vector.

        Args:
            embedding: Embedding to look up documents similar to.
            k: Number of Documents to return. Defaults to 4.
            filter: Optional metadata filter.

        Returns:
            List of Documents most similar to the query vector.
        """
        if not isinstance(k, int):
            raise TypeError('k must be an int')
        if k < 0:
            raise ValueError('k must be non-negative')
        select_items = [
            'id',
            'document',
            *(_METADATA_PREFIX + c for c in self._metadata_columns),
        ]
        args: list = [k]
        if filter:
            condition, args[len(args):] = _filter_to_condition(filter)
            where_clause = 'WHERE ' + condition
        else:
            where_clause = ''
        args.append(','.join(map(str, embedding)))
        query = (
            f'SELECT TOP ? {",".join(select_items)} '
            f'FROM {self._collection_name} '
            f'{where_clause} '
            f'ORDER BY {self._similarity_metric}(embedding,?) DESC'
        )
        with self._connection.cursor() as cursor:
            cursor.execute(query, args)
            return [Document(row[1], id=row[0], metadata=self._get_metadata(row[2:])) for row in cursor]

    def similarity_search_with_score(
            self,
            query: str,
            k: int = 4,
            filter: dict | None = None,
    ) -> list[tuple[Document, float]]:
        """Run similarity search with distance. Smaller distance means more
        similar.

        Args:
            query: Input text.
            k: Number of Documents to return. Defaults to 4.
            filter: Optional metadata filter.

        Returns:
            List of tuples of (doc, distance).
        """
        if not isinstance(k, int):
            raise TypeError('k must be an int')
        if k < 0:
            raise ValueError('k must be non-negative')
        embedding = self._embedding_function.embed_query(query)
        select_items = [
            'id',
            'document',
            f'{self._similarity_metric}(embedding,?) AS similarity',
            *(_METADATA_PREFIX + c for c in self._metadata_columns),
        ]
        args = [k, ','.join(map(str, embedding))]
        if filter:
            condition, args[len(args):] = _filter_to_condition(filter)
            where_clause = 'WHERE ' + condition
        else:
            where_clause = ''
        query = (
            f'SELECT TOP ? {",".join(select_items)} '
            f'FROM {self._collection_name} '
            f'{where_clause} ORDER BY similarity DESC'
        )
        with self._connection.cursor() as cursor:
            cursor.execute(query, args)
            # remove float() cast when DP-446109 is fixed
            return [(Document(row[1], id=row[0], metadata=self._get_metadata(row[3:])), 1-float(row[2])) for row in cursor]

    def _clean_metadata(self):
        """Delete metadata columns that contain all NULLs and their indices."""
        drop_columns = []
        with self._connection.cursor() as cursor:
            for metadata_column in list(self._metadata_columns):
                # list() creates a copy, so it's safe to modify
                # self._metadata_columns within the loop
                metadata_column_with_prefix = _METADATA_PREFIX + metadata_column
                cursor.execute(
                    f'SELECT COUNT(*) FROM {self._collection_name} '
                    f'WHERE {metadata_column_with_prefix} IS NOT NULL'
                )
                if not cursor.fetchone()[0]:
                    del self._metadata_columns[metadata_column]
                    drop_columns.append(metadata_column_with_prefix + ' CASCADE %DELDATA')
            if drop_columns:
                cursor.execute(
                    f'ALTER TABLE {self._collection_name} '
                    f'DROP COLUMN {",".join(drop_columns)}'
                )

    @_transaction(commit=False)
    def delete(
            self,
            ids: list[str] | None = None,
            drop_table: bool = False,
            clean_metadata: bool = False,
    ) -> bool:
        """Delete by vector ID. If at least one ID does not exist or is
        duplicated, then deletion fails and nothing is deleted.

        Args:
            ids: List of ids to delete. If None, delete all. Default is None.
            drop_table: Whether to delete the backend table if ids is None.
                Default is False.
            clean_metadata: Whether to delete metadata columns and indices in
                the backend table corresponding to metadata keys that the
                existing documents no longer use.

        Returns:
            bool: True if deletion is successful, False otherwise.
        """
        if ids == []:
            if clean_metadata:
                self._clean_metadata()
                self._connection.commit()
            return True
        with self._connection.cursor() as cursor:
            if ids is None:
                if drop_table:
                    cursor.execute(f'DROP TABLE {self._collection_name}')
                else:
                    cursor.execute(f'DELETE FROM {self._collection_name}')
                    if clean_metadata:
                        self._clean_metadata()
                self._connection.commit()
                return True
            n_deleted = 0
            for batch_ids in batched(ids, self._BATCH_SIZE):
                cursor.executemany(f'DELETE FROM {self._collection_name} WHERE ID=?', [(id,) for id in batch_ids])
                n_deleted += cursor.rowcount
            if n_deleted == len(ids):
                if clean_metadata:
                    self._clean_metadata()
                self._connection.commit()
                return True
            else:
                self._connection.rollback()
                return False

    def get_by_ids(self, ids: collections.abc.Sequence[str], /) -> list[Document]:
        """Get documents by their IDs.

        The returned documents are expected to have the ID field set to the ID
        of the document in the vector store.

        Fewer documents may be returned than requested if some IDs are not
        found or if there are duplicated IDs.

        Users should not assume that the order of the returned documents
        matches the order of the input IDs. Instead, users should rely on the
        ID field of the returned documents.

        This method should **NOT** raise exceptions if no documents are found
        for some IDs.

        Args:
            ids: List of ids to retrieve.

        Returns:
            List of Documents.
        """
        if not ids:
            return []
        docs = []
        select_items = [
            'id',
            'document',
            *(_METADATA_PREFIX + c for c in self._metadata_columns)
        ]
        with self._connection.cursor() as cursor:
            for batch_ids in batched(ids, self._BATCH_SIZE):
                cursor.execute(
                    f'SELECT {",".join(select_items)} '
                    f'FROM {self._collection_name} '
                    f'WHERE id in ({",".join("?"*len(batch_ids))})',
                    batch_ids
                )
                docs.extend(Document(row[1], id=row[0], metadata=self._get_metadata(row[2:])) for row in cursor)
        return docs

    def max_marginal_relevance_search(
            self,
            query: str,
            k: int = 4,
            fetch_k: int = 20,
            lambda_mult: float = 0.5,
            filter: dict | None = None,
    ) -> list[Document]:
        """Return docs selected using the maximal marginal relevance.

        Maximal marginal relevance optimizes for similarity to query AND
        diversity among selected documents.

        Args:
            query: Text to look up documents similar to.
            k: Number of `Document` objects to return.
            fetch_k: Number of `Document` objects to fetch to pass to MMR
                algorithm.
            lambda_mult: Number between `0` and `1` that determines the degree
                of diversity among the results with `0` corresponding to
                maximum diversity and `1` to minimum diversity.
            filter: Optional metadata filter.

        Returns:
            List of `Document` objects selected by maximal marginal relevance.
        """
        embedding = self._embedding_function.embed_query(query)
        return self.max_marginal_relevance_search_by_vector(embedding, k, fetch_k, lambda_mult, filter)

    def max_marginal_relevance_search_by_vector(
            self,
            embedding: list[float],
            k: int = 4,
            fetch_k: int = 20,
            lambda_mult: float = 0.5,
            filter: dict | None = None,
    ) -> list[Document]:
        """Return docs selected using the maximal marginal relevance.

        Maximal marginal relevance optimizes for similarity to query AND
        diversity among selected documents.

        Args:
            embedding: Embedding to look up documents similar to.
            k: Number of `Document` objects to return.
            fetch_k: Number of `Document` objects to fetch to pass to MMR
                algorithm.
            lambda_mult: Number between `0` and `1` that determines the degree
                of diversity among the results with `0` corresponding to
                maximum diversity and `1` to minimum diversity.
            filter: Optional metadata filter.

        Returns:
            List of `Document` objects selected by maximal marginal relevance.
        """
        if not isinstance(k, int):
            raise TypeError('k must be an int')
        if k < 0:
            raise ValueError('k must be non-negative')
        if not isinstance(fetch_k, int):
            raise TypeError('fetch_k must be an int')
        if fetch_k < 0:
            raise ValueError('fetch_k must be non-negative')
        if lambda_mult < 0 or lambda_mult > 1:
            raise ValueError('lambda_mult must be in the range 0 to 1')
        if not k or not fetch_k:
            return []

        # first obtain fetch_k most relevant results
        select_items = [
            'id',
            'document',
            'embedding',
            f'{self._similarity_metric}(embedding,?) AS similarity',
            *(_METADATA_PREFIX + c for c in self._metadata_columns),
        ]
        args = [fetch_k, ','.join(map(str, embedding))]
        if filter:
            condition, args[len(args):] = _filter_to_condition(filter)
            where_clause = 'WHERE ' + condition
        else:
            where_clause = ''
        query = (
            f'SELECT TOP ? {",".join(select_items)} '
            f'FROM {self._collection_name} '
            f'{where_clause} '
            f'ORDER BY similarity DESC'
        )
        with self._connection.cursor() as cursor:
            cursor.execute(query, args)

            # initialize selected documents with the most relevant document
            if (row := cursor.fetchone()) is None:
                return []
            selected_docs = [Document(row[1], id=row[0], metadata=self._get_metadata(row[4:]))]

            # candidate_items starts as the next most relevant up to fetch_k-1
            # documents and associated information as a mapping from document
            # ID to a tuple, where each tuple is
            # (document, embedding as comma-delimited string, similarity to query)
            # remove float() cast when DP-446109 is fixed
            candidate_items = {row[0]: (Document(row[1], id=row[0], metadata=self._get_metadata(row[4:])), row[2], float(row[3])) for row in cursor}
            # mapping from candidate document ID to this document's similarity
            # score with the most similar selected document
            candidate_redundant_scores = {}
            while len(selected_docs) < k and candidate_items:
                # Obtain the highest similarity score of each candidate with
                # the selected documents. To do this, for each candidate,
                # obtain the similarity score with the most recently selected
                # document and then compare that value with the highest
                # similarity score among the previous selected documents.
                select_items = [f'{self._similarity_metric}(embedding,?)'] * len(candidate_items)
                query = (
                    f'SELECT {",".join(select_items)} '
                    f'FROM {self._collection_name} WHERE id = ?'
                )
                args = [candidate_item[1] for candidate_item in candidate_items.values()]
                args.append(selected_docs[-1].id)
                cursor.execute(query, args)
                row = cursor.fetchone()
                for candidate_id, similarity_score in zip(candidate_items, row, strict=True):
                    try:
                        candidate_redundant_scores[candidate_id] = max(candidate_redundant_scores[candidate_id], similarity_score)
                    except KeyError:
                        candidate_redundant_scores[candidate_id] = similarity_score
                best_mmr_score = float('-inf')
                for candidate_id, (_, _, candidate_similarity_to_query) in candidate_items.items():
                    # update the candidate with the best MMR score so far
                    mmr_score = lambda_mult * candidate_similarity_to_query - (1 - lambda_mult) * candidate_redundant_scores[candidate_id]
                    if mmr_score > best_mmr_score:
                        best_mmr_score = mmr_score
                        best_id = candidate_id
                selected_docs.append(candidate_items[best_id][0])
                del candidate_items[best_id]
            return selected_docs
